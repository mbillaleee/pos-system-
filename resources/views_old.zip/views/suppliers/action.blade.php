



<a href="javascript:void(0)" data-toggle="tooltip" onClick="editFunc({{ $id }})" data-original-title="Edit" class="edit text-info">

<i class="fa-solid fa-pen-to-square"></i>

</a>

<!-- <a href="javascript:void(0);" id="delete-compnay" onClick="deleteFunc({{ $id }})" data-toggle="tooltip" data-original-title="Delete" class="delete text-danger">

<i class="fa-solid fa-trash-can"></i>

</a> -->